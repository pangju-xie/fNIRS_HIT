import numpy as np

class Sensor:
    def __init__(self, id, type):
        self.id = id   # mac低3字节
        self.type = type  # 传感器类型
        self.channel = []  # 传感器通道
        self.raw = np.array([])  # fnirs/nirs: 光电信号 格式: [[packetId, Red, Ir]]
        self.resolved = np.array([])  # fnirs/nirs: 血氧数据 格式: [[packetId, hb, hbo2]]

    def ResetData(self):
        self.raw = np.zeros([0, 2 * len(self.channel) + 1])
        self.resolved = np.zeros([0, 2 * len(self.channel) + 1])

    def Update(self, data):
        if self.type == 4:
            packet_id = data[-1] + (256 * data[-2]) + (256 * 256 * data[-3]) + (256 * 256 * 256 * data[-4])
            raw = np.array([])
            for i in range(len(self.channel) * 2):  # 遍历数据: ch1-red, ch1-ir, ch2-red, ...  每段数据3个字节
                if data[i * 3 + 2] > 128 or (data[i * 3 + 0] == 0 and data[i * 3 + 1] == 0 and data[i * 3 + 2] == 0):  # 实际为负电压, 此次按1LSB计算防止求解时lg为负
                    vol = 6.7392e-7
                else:
                    vol = (data[i * 3 + 0] + data[i * 3 + 1] * 256 + data[i * 3 + 2] * 65536) * 6.7392e-7
                raw = np.append(raw, vol)

            dataline = np.concatenate((np.array([packet_id]), raw)).reshape(1, -1)
            self.raw = np.concatenate((self.raw, dataline), axis=0)

            # 计算血氧数据
            od = -np.log(dataline[0, 1:] / self.raw[0, 1:])
            # 750 / 850
            # Hb 1405.24 518
            # HbO2 691.32 1058
            # DPF 1.02 0.91 (*6.32)
            # 距离d暂未加入, 因此计算得到的是相对数值
            oxy = np.array([])
            for i in range(od.shape[0] // 2):
                D = np.array([[ 0.91903065, -0.67310409],
                              [-0.44996019,  1.36821268]])
                oxy = np.concatenate((oxy, np.dot(D, np.array([[od[i * 2]], [od[i * 2 + 1]]])).reshape(-1)))
            self.resolved = np.concatenate((self.resolved, np.concatenate((np.array([packet_id]), oxy)).reshape(1, -1)), axis=0)



# import numpy as np

# a = np.array([
#     [1405.24 * 1.02, 691.32 * 1.02],
#     [518 * 0.91, 1058 * 0.91]
# ])

# a_inv = np.linalg.inv(a) * 1000

# print(a_inv)
